package assignment;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;

public class Translate {
	ArrayList<String> words = new ArrayList<String>();
	ArrayList<String> modifiedWords = new ArrayList<String>();
	Hashtable <String, String> excel_dic = new Hashtable<String, String>();	

	String currentDirectory = System.getProperty("user.dir");
	String fileLocation = currentDirectory + "\\Exeter\\src\\assignment";
	
	public static void main(String[] args) throws IOException
	{	
		Translate translate =new Translate();
		translate.listMethod();
		translate.generate_dictionary();
		translate.method1();
		translate.generate_translated_File();
	}
	
	public void method1() throws IOException
	{
		String filePath = fileLocation + "\\find_words.txt";
		Path path = Paths.get(filePath);
		String contents = Files.readString(path);
		String[] find_words=contents.split("\\s");
		for(int i=0; i< words.size();i++)
		{
			for(int j=0;j<find_words.length;j++)
			{
				if( words.get(i) != null && words.get(i).equalsIgnoreCase(find_words[j]) && excel_dic.containsKey(find_words[j]))
				{
					replace_words(i,excel_dic.get(find_words[j]));
					break;
				}				
			}
		}
	}
	
	public void listMethod() throws IOException
	{
		BufferedReader reader;
		try
		{
			String filePath = fileLocation + "\\t8.shakespeare.txt";
			reader = new BufferedReader(new FileReader(
					filePath));
			String line = reader.readLine();
			
			while (line != null) {
				line = reader.readLine();
				if(line != null) {
				String[] strSplit = line.split("\\s");
		        ArrayList<String> strList = new ArrayList<String>(
		            Arrays.asList(strSplit));
				 words.addAll(strList);
			}}
			modifiedWords = words;
			reader.close();		
		} 
		catch(NullPointerException e) 
		{
			System.out.println("NullPointerException thrown!");
		}
	}
	
	public void generate_dictionary() throws IOException
	{
		BufferedReader reader;
		ArrayList<String> dicValue = new ArrayList<String>();
		try
		{
			String filePath = fileLocation + "\\french_dictionary.csv";
			reader = new BufferedReader(new FileReader(
					filePath));
			String line = reader.readLine();
			while (line != null)
			{
				line = reader.readLine();
				dicValue.add(line);
			}
			for(int j=0;j<dicValue.size();j++)
			{
				String[] exactValue = dicValue.get(j).split(",");
				excel_dic.put(exactValue[0], exactValue[1]);			
			}
			reader.close();	
		} 
		catch(NullPointerException e) 
		{
			System.out.println("NullPointerException thrown!");
		}
	}
	
	public void replace_words(int indexVal,String frenchText)
	{
		modifiedWords.set(indexVal, frenchText);
	}
	
	public void generate_translated_File() throws IOException
	{
		String filePath = fileLocation + "\\modifiedContent.txt";
		FileWriter writer = new FileWriter(filePath); 
		for(String str: modifiedWords) 
		{
		  writer.write(str + " ");
		}
		writer.close();
	}
	
}
